# cuda-kernel-suite

A CUDA kernel optimization suite — four kernels progressing from memory-bound
streaming to compute-bound matrix multiplication, each with Nsight Compute
profiles and speedup benchmarks.

Target hardware: Tesla T4 (sm_75) | CUDA 12.8 | Nsight Compute 2025.1.1
Environment: Google Colab (GPU runtime)

## Kernels

| # | Kernel | Focus | Status |
|---|--------|-------|--------|
| 1 | vector_add | Baseline, memory-bound streaming | done |
| 2 | reduction (naive/shared/warp) | Shared memory, bank conflicts, warp shuffle | pending |
| 3 | matmul (naive) | Compute-bound baseline, occupancy | pending |
| 4 | matmul (tiled) | Shared memory tiling, register blocking | pending |

## Results Summary

### 1. vector_add
- Effective bandwidth: ~262 GB/s (~82% of T4 peak)
- Nsight DRAM throughput: 90.38%
- Compute (SM) throughput: 23.44%
- Achieved occupancy: 82.25%
- Registers per thread: 16
- Conclusion: memory-bound; block size between 32 and 1024 does not
  materially change bandwidth (all saturate DRAM). 256 chosen as default.

Full analysis: src/01_vector_add/README.md

## Repository Layout

- src/                  kernel sources + per-kernel READMEs
- benchmarks/results/   CSV outputs from sweeps
- profiles/             Nsight Compute .ncu-rep reports
- plots/                Speedup/bandwidth charts
- docs/                 Methodology, findings, blog draft

## How to Reproduce

Compile:
nvcc -O3 -arch=sm_75 -lineinfo -o vector_add_sweep vector_add_sweep.cu

Run sweep:
./vector_add_sweep > benchmarks/results/vector_add.csv

Profile:
ncu --set full -c 1 -o profiles/vecadd_best ./vector_add_sweep
ncu --import profiles/vecadd_best.ncu-rep --page details

## Timeline
- Week 1: vector_add baseline (done)
- Week 2: reduction kernels
- Week 3: naive matmul
- Week 4: tiled matmul + polish
