# Vector Add — CUDA Kernel Baseline

## Goal
Establish a baseline streaming kernel and verify it is memory-bandwidth-bound
using Nsight Compute on a Tesla T4 (sm_75).

## Kernel

```cuda
__global__ void vectorAdd(const float* __restrict__ A,
                          const float* __restrict__ B,
                          float* __restrict__ C, int N) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < N) C[i] = A[i] + B[i];
}
