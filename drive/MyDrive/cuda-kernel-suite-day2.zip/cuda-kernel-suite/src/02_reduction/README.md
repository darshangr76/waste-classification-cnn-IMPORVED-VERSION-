# Reduction — Naive Baseline

## Goal
Establish a baseline for array reduction and expose the cost of tree
reduction with per-step `__syncthreads()` and one atomicAdd per block.

## Kernel

Each thread loads one element into shared memory, the block tree-reduces
in shared memory with a barrier after every step, then thread 0 issues one
`atomicAdd` to global memory.

## Configuration
- N = 16,777,216 floats (64 MB)
- block size = 256, grid = 65,536
- 5 warmup + 50 timed iterations
- Compile: nvcc -O3 -arch=sm_75 -lineinfo

## Results

| Metric | Value |
|--------|-------|
| Time | 1.224 ms (unprofiled) |
| Effective bandwidth | 54.8 GB/s |
| Result | PASS (16777216.0) |

### Nsight Compute

| Metric | Value | % of peak |
|--------|-------|-----------|
| Duration | 1.60 ms | - |
| DRAM Throughput | - | 18.03% |
| Compute (SM) Throughput | - | 76.33% |
| Achieved Occupancy | - | 90.29% |
| Registers / thread | 16 | - |

## Analysis

**The kernel is compute/instruction bound, not memory bound.**

The DRAM-to-SM ratio is roughly 1:4 — the *inverse* of vector_add
(which was 4:1 in favor of DRAM). Three causes:

1. **Divergent tree reduction.** The loop
   `for (s = blockDim.x/2; s > 0; s >>= 1)` starts with 128 of 256
   threads active and finishes with 1 of 256. Over the loop, average
   active lanes is ~32, so ~88% of thread-slots are idle at any time.

2. **Barrier stalls.** `__syncthreads()` after every tree step means 8
   barriers per block × 65,536 blocks = 524,288 barrier stalls. All warps
   wait for the slowest lane at every step.

3. **atomicAdd contention.** One atomicAdd per block to a single global
   address serializes 65,536 atomic operations.

The result: the memory bus is idle 82% of the time (DRAM 18%),
while the SMs spend most cycles on address arithmetic, predicate
evaluation, and barrier waits (SM 76%).

## Key comparison

| Metric | vector_add | reduction_naive |
|--------|-----------|-----------------|
| DRAM % | 90.4% | 18.0% |
| SM % | 23.4% | 76.3% |
| Occupancy | 82.3% | 90.3% |
| Time | 0.77 ms | 1.60 ms |

Same GPU, same data volume class, opposite bottleneck. This is the
motivation for the shared-memory and warp-shuffle variants.

## Artifacts
- profiles/reduction_naive.ncu-rep
- benchmarks/results/reduction.csv
